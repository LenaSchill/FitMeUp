#pragma once
#include <gmock/gmock.h>
#include <gtest/gtest.h>
#include <iostream>
#include <string>
#include "pch.h"
#include <stdio.h>



using namespace std;
using ::testing::AtLeast;
using ::testing::Return;
using ::testing::_;
using ::testing::Test;
using ::testing::MatchesRegex;
using ::testing::StartsWith;

//Datenbank-Test (LOGIN)

class DataBaseConnect {   //diese Klasse muss gemocked werden -> soll Datenbank nachstellen
public:
	virtual bool login(string username, string password) {
		return true;
	}
	virtual bool logout(string username) {
		return true;
	}
	virtual int fetchRecord() {
		return -1;
	}
};

class MockDB: public DataBaseConnect {   //Mock-Klasse
public:
	MOCK_METHOD0(fetchRecord, int());
	MOCK_METHOD1(logout, bool(string username));
	MOCK_METHOD2(login, bool(string username, string password));
	//MOCK_METHOD3(login2, bool(string username, string password));
};


class MyDataBase {
	DataBaseConnect &dbC;  
public:
	MyDataBase(DataBaseConnect &_dbC) : dbC(_dbC) {}
	int Init(string username, string password) {
		if (dbC.login(username, password) != true) {
			cout << "DB FAILURE" << endl; return 1;
		}
		else {
			cout << "DB SUCCESS" << endl; return 1;
		}
	}
};

class DB {
	string id;

public:
	DB(string _id) : id(_id) {}
	string GetID() { return id; }
};



class KalorienCalculator {
public:
	KalorienCalculator();
	int calculateKalorien(int kal, double grundumsatz, double leistungsumsatz);
};

KalorienCalculator::KalorienCalculator() {

}

int KalorienCalculator::calculateKalorien(int kal, double grundumsatz, double leistungsumsatz) {
	double _grundumsatz;
	double _leistungsumsatz;
	double umsatz = 0;

	if (grundumsatz == 2000) {
		_grundumsatz = 2000;
		cout << "JEIJ" << endl << _grundumsatz << endl; return 1;
	}
	else {
		_grundumsatz = -2000;
		cout << "FAILED" << endl << _grundumsatz << endl; return 1;
	}
	
}