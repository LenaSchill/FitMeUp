#include "pch.h"
#include "Test1.h"
#include "googlemock/include/gmock/gmock-matchers.h"

//Erkl�rung: Google Test Assertions: 
//Success - Non-Fatal Failures (EXPECT_) (stoppt nicht Durchf�hrung des Tests) - Fatal Failures (ASSERT_) (stoppt Durchf�hrung des Tests)


TEST(Datab, test_1) {
	//Arrange
	DB mc("root");

	//Act
	string value = mc.GetID();

	//Assert
	ASSERT_STREQ(value.c_str(), "root");

	//Expect
	EXPECT_STREQ(value.c_str(), "root"); //EXPECT_STREQ() und ASSERT_STREQ() = equal, testen beide die Qualit�t des Strings
}

TEST(MyDBTest, LoginTest) {
	//Arange
	MockDB mdb;     //Instanz Mock-Klasse wird anstelle Instanz von Database-Klasse erstellt
	MyDataBase db(mdb);
	EXPECT_CALL(mdb, login("SuperMax", "IchBinLost123!"))
		.Times(1)
		.WillOnce(Return(true));

	//Act
	int retValue = db.Init("SuperMax", "IchBinLost123!");

	//Assert
	EXPECT_EQ(retValue, 1);
}


TEST(MyDBTest, LoginTest1) {
	//Arrange
	MockDB mdb;     //Instanz Mock-Klasse wird anstelle Instanz von Database-Klasse erstellt
	MyDataBase db(mdb);
	ON_CALL(mdb, login(_, _)).WillByDefault(Return(true));

	//Act
	int retValue = db.Init("SuperMax", "IchBinLost123!");

	//Assert
	EXPECT_EQ(retValue, 1);
}


//Kalorien-Test
TEST(Kalorien, NegativValues) {  //Dieser Test testet explizit den neg. Wert -2000, l�sst den Test nicht "Failen" und bricht nicht ab. Test wird als "PASSED" angezeigt
	//Arrange                    //Es wird ein negativ Wert �bergeben, somit leitet es weiter zu der else-Bedingung -> FAILED und -2000 wird ausgegeben. 
	KalorienCalculator kl;       //Negativ-Werte werden somit in der Kalorien-Fkt. akzeptiert

	//Act
	int retValue = kl.calculateKalorien(250, -2000, 2);

	//Assert
	EXPECT_EQ(retValue, 1);

}

TEST(Kalorien, PositivValues) { //Dieser Test testet postive Eingabewerte, in dem Fall explizit 2000. Test "PASSED" und gibt "JEIJ", sowie 2000 aus. 
	//Arrange                   //
	KalorienCalculator kl;

	//Act
	int retValue = kl.calculateKalorien(250, 2000, 2);

	//Assert
	EXPECT_EQ(retValue, 1);
}

//MatchersTest - testet einen String, der im Programm bei "cout" ausgegeben wird -> z.B. cout von Wasserstatus "dehydriert"
TEST(MatchersTest, ChallengeTest) {
	string test_string("1-Tages Challenge: Trinke ein Glas mehr am Tag.");
	EXPECT_THAT(test_string, StartsWith("1-Tages Challenge:"));
	EXPECT_THAT(test_string, MatchesRegex(".*ein.*Glas.*"));
}